# patrik-eskelinen.github.io
My personal website, contains job-search related information, original content, opinions, contact information and any other sort of information which I find worthy of sharing
